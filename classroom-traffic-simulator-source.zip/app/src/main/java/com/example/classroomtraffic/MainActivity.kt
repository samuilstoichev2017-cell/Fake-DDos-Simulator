package com.example.classroomtraffic

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.NumberFormat
import java.util.Locale
import kotlin.random.Random

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var running = true
    private var mode = Mode.NORMAL
    private var total = 0L
    private var rps = 0
    private var load = 12
    private var elapsed = 0
    private lateinit var status: TextView
    private lateinit var totalView: TextView
    private lateinit var rpsView: TextView
    private lateinit var loadView: TextView
    private lateinit var barView: TextView
    private lateinit var graphView: TextView
    private val history = ArrayDeque<Int>()

    private enum class Mode { NORMAL, SPIKE, RECOVERY }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            elapsed++
            rps = when (mode) {
                Mode.NORMAL -> Random.nextInt(15, 61)
                Mode.SPIKE -> Random.nextInt(450, 901)
                Mode.RECOVERY -> Random.nextInt(20, 91)
            }
            total += rps
            val target = when (mode) {
                Mode.NORMAL -> Random.nextInt(8, 27)
                Mode.SPIKE -> Random.nextInt(82, 101)
                Mode.RECOVERY -> maxOf(8, 65 - elapsed / 2)
            }
            load = (load + target) / 2
            load = load.coerceIn(0, 100)
            history.addLast(rps)
            while (history.size > 24) history.removeFirst()
            render()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 16, 28)
        window.navigationBarColor = Color.rgb(10, 16, 28)
        buildUi()
        handler.post(tick)
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
            setBackgroundColor(Color.rgb(10, 16, 28))
        }
        scroll.addView(root)

        root.addView(text("CLASSROOM TRAFFIC LAB", 23, Color.WHITE, true))
        root.addView(text("Offline network-traffic concept simulator", 14, Color.rgb(164, 177, 199), false).apply {
            setPadding(0, dp(5), 0, dp(16))
        })
        root.addView(card {
            addView(text("SIMULATION STATUS", 12, Color.rgb(139, 158, 186), true))
            status = text("● NORMAL", 21, Color.rgb(91, 220, 160), true)
            status.setPadding(0, dp(8), 0, dp(4))
            addView(status)
            addView(text("All numbers are fictional. No network traffic is sent.", 13, Color.rgb(164, 177, 199), false))
        })
        root.addView(space(12))
        val metrics = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = card {
            addView(text("SIMULATED REQ/S", 11, Color.rgb(139, 158, 186), true))
            rpsView = text("0", 26, Color.WHITE, true)
            addView(rpsView)
        }
        val right = card {
            addView(text("TOTAL REQUESTS", 11, Color.rgb(139, 158, 186), true))
            totalView = text("0", 26, Color.WHITE, true)
            addView(totalView)
        }
        metrics.addView(left, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        metrics.addView(right, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        root.addView(metrics)
        root.addView(space(12))
        root.addView(card {
            addView(text("FICTIONAL SERVER LOAD", 12, Color.rgb(139, 158, 186), true))
            loadView = text("12%", 29, Color.WHITE, true).apply { setPadding(0, dp(5), 0, dp(5)) }
            addView(loadView)
            barView = text("[##------------------]", 18, Color.rgb(91, 220, 160), true)
            addView(barView)
            addView(text("Illustrative load indicator, not actual device/server CPU.", 12, Color.rgb(164, 177, 199), false))
        })
        root.addView(space(12))
        root.addView(card {
            addView(text("TRAFFIC HISTORY (LAST 24 TICKS)", 12, Color.rgb(139, 158, 186), true))
            graphView = text("Waiting for samples…", 13, Color.rgb(91, 190, 255), true).apply {
                setPadding(0, dp(12), 0, dp(4))
            }
            addView(graphView)
        })
        root.addView(space(12))
        root.addView(text("CHOOSE A SCENARIO", 13, Color.rgb(164, 177, 199), true))
        root.addView(space(8))
        root.addView(actionButton("1  Normal traffic") { setMode(Mode.NORMAL) })
        root.addView(space(8))
        root.addView(actionButton("2  Sudden traffic spike") { setMode(Mode.SPIKE) })
        root.addView(space(8))
        root.addView(actionButton("3  Recovery") { setMode(Mode.RECOVERY) })
        root.addView(space(8))
        root.addView(actionButton("Reset simulation") {
            total = 0
            elapsed = 0
            rps = 0
            load = 12
            history.clear()
            setMode(Mode.NORMAL)
            render()
        })
        root.addView(space(14))
        root.addView(text("Teaching prompt: What happens to availability when demand exceeds capacity? Discuss monitoring, rate limiting, caching, and incident response.", 13, Color.rgb(164, 177, 199), false))
        setContentView(scroll)
    }

    private fun setMode(newMode: Mode) {
        mode = newMode
        elapsed = 0
        render()
    }

    private fun render() {
        if (!::status.isInitialized) return
        status.text = when (mode) {
            Mode.NORMAL -> "● NORMAL"
            Mode.SPIKE -> "● SIMULATED SPIKE"
            Mode.RECOVERY -> "● RECOVERY"
        }
        status.setTextColor(when (mode) {
            Mode.NORMAL -> Color.rgb(91, 220, 160)
            Mode.SPIKE -> Color.rgb(255, 112, 112)
            Mode.RECOVERY -> Color.rgb(255, 195, 92)
        })
        rpsView.text = NumberFormat.getIntegerInstance(Locale.US).format(rps)
        totalView.text = NumberFormat.getIntegerInstance(Locale.US).format(total)
        loadView.text = "$load%"
        val blocks = load / 5
        barView.text = "[" + "#".repeat(blocks) + "-".repeat(20 - blocks) + "]"
        barView.setTextColor(if (load >= 80) Color.rgb(255, 112, 112) else Color.rgb(91, 220, 160))
        graphView.text = history.joinToString(" ") { value ->
            when {
                value >= 450 -> "▇"
                value >= 200 -> "▅"
                value >= 80 -> "▃"
                else -> "▁"
            }
        }.ifBlank { "Waiting for samples…" }
    }

    private fun card(content: LinearLayout.() -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundColor(Color.rgb(21, 31, 49))
            content()
        }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(39, 78, 125)))
            setOnClickListener { action() }
        }

    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        super.onDestroy()
    }
}
