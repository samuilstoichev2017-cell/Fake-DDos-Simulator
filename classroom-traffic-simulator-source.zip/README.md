# Classroom Traffic Lab (Android)

A native Android app that demonstrates fictional traffic levels for teaching. It does not open network sockets, send requests, or perform a real stress test.

## Build an APK using GitHub Actions

1. Create a new GitHub repository.
2. Upload the contents of this project to the repository (the `.github` folder must be included).
3. Open the repository's **Actions** tab.
4. Select **Build classroom simulator APK** and click **Run workflow**. Alternatively, push the files to the `main` branch.
5. When the workflow finishes, open its run and download the `classroom-traffic-lab-apk` artifact.
6. Extract the downloaded ZIP to get `app-debug.apk`, then install it on your Android device. Android may ask you to allow installation from that source.

## Build locally

Requires JDK 17, Android SDK (platform 35), and Gradle 8.9:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Features

- Normal, simulated-spike, and recovery scenarios
- Fictional requests-per-second counter
- Fictional load meter and recent traffic history
- No internet permission and no real network traffic
